<?php
echo "Successfully submitted information!";